for(var x = 1; x < 20; x+=2){
    console.log(x);
}