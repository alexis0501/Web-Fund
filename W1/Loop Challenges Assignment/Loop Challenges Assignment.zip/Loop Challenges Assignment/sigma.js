var sum = 0;

for(var x = 1; x <= 100; x++){
    sum += x
}
console.log(sum);