var product = 1;

for(var x = 1; x <=12; x++){
    product *= x
}

console.log(product);