for(var x = 4; x >= -3.5; x -= 1.5){
    console.log(x)
}