for(var x = 100; x > 0; x -= 1) {
    if( x % 3 == 0){
        console.log(x)
    }
}